package com.example.chuck_norris_io

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
