import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:json_annotation/json_annotation.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

void main() => runApp(MaterialApp(
  theme: ThemeData(
    primaryColor: Colors.blue,
  ),
  home: Home(),
));

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String joke =
      'When Chuck Norris was in the Air Force, everyone, even the generals, saluted him first.';

  void getTheJoke() async {
    var searchResult =
    await http.get(Uri.parse('https://api.chucknorris.io/jokes/random'));
    var decoded = json.decode(searchResult.body)['value'];

    setState(() {
      joke = decoded;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ChuckNorris.io'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Column(
            children: [
              Head(),
              Container(
                margin: const EdgeInsets.all(15.0),
                padding: const EdgeInsets.all(3.0),
                decoration:
                BoxDecoration(border: Border.all(color: Colors.blue)),
                width: 300,
                //color: Colors.blue,
                child: Text(
                  joke,
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ],
          )
        ]),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.thumb_up),
        backgroundColor: Colors.blue,
        onPressed: () {
          setState(() {
            getTheJoke();
          });
        },
      ),
    );
  }
}

class Head extends StatelessWidget {
  const Head({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Column(
            children: [
              Column(children: const [
                Padding(padding: EdgeInsets.only(top: 30)),
                CircleAvatar(
                  backgroundImage: AssetImage('assets/chuck.jpeg'),
                  radius: 100,
                ),
                Padding(padding: EdgeInsets.only(top: 10)),
                Text("Hi, I'm Chuck Norris and I'll tell you some of my jokes"),
                Padding(padding: EdgeInsets.only(top: 150)),
              ]),
            ],
          )
        ])
      );
  }
}
